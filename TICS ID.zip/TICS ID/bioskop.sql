-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 27 Des 2024 pada 16.14
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bioskop`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `administrator`
--

CREATE TABLE `administrator` (
  `username_admin` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `administrator`
--

INSERT INTO `administrator` (`username_admin`, `password`) VALUES
('admin', 'admin123');

-- --------------------------------------------------------

--
-- Struktur dari tabel `carousel_image`
--

CREATE TABLE `carousel_image` (
  `id` int(255) NOT NULL,
  `image_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `carousel_image`
--

INSERT INTO `carousel_image` (`id`, `image_name`) VALUES
(13, '676ada5111769.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `coming_soon`
--

CREATE TABLE `coming_soon` (
  `id` int(255) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `trailer` varchar(255) NOT NULL,
  `poster` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `coming_soon`
--

INSERT INTO `coming_soon` (`id`, `judul`, `genre`, `trailer`, `poster`) VALUES
(1010, 'Cars 2', 'Animation', 'https://youtube.com/embed/hDZ7y8RP5HE?si', 'VirtualBox_Zidan083_15_12_2024_19_51_41.png'),
(1011, 'Hulk', 'Action', 'https://youtube.com/embed/hDZ7y8RP5HE?si', 'incredible_hulk_480x.progressive (1).png'),
(1020, 'The Marvels', 'Animation | Adventure', 'https://youtube.com/embed/hDZ7y8RP5HE?si', 'the-marvels_pnk1tryd_480x.progressive.png'),
(8723, 'Spiderman-2', 'Action', 'https://youtube.com/embed/hDZ7y8RP5HE?si', 'Monterverse23.png'),
(9597, 'Jurassic World: Dominion', 'Action', 'https://youtube.com/embed/hDZ7y8RP5HE?si', 'VirtualBox_Zidan083_11_12_2024_17_46_12.png'),
(92753, 'Black Panther', 'Action | Superhero', 'https://youtube.com/embed/hDZ7y8RP5HE?si', '1646858744007.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `film`
--

CREATE TABLE `film` (
  `id` int(50) NOT NULL,
  `judul` varchar(50) NOT NULL,
  `genre` varchar(50) NOT NULL,
  `jadwal` varchar(50) NOT NULL,
  `waktu_tayang` varchar(50) NOT NULL,
  `harga` varchar(50) NOT NULL,
  `theater` varchar(255) NOT NULL,
  `poster` varchar(255) NOT NULL,
  `trailer` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `film`
--

INSERT INTO `film` (`id`, `judul`, `genre`, `jadwal`, `waktu_tayang`, `harga`, `theater`, `poster`, `trailer`) VALUES
(1001, 'Venom 2', 'Action', '2025-12-12', '12:21', '35000', '2', 'venom-the-last-dance_90m5c26k_480x.progressive.png', 'https://youtube.com/embed/hDZ7y8RP5HE?si'),
(1002, 'Toy Story', 'Animation', '2025-12-12', '15:15', '35.000', '4', 'ToyStory.mpw.102287_480x.progressive (1).png', ''),
(1003, 'Deadpool & Wolverine', 'Action', '2025-12-12', '12:12', '35000', '1', 'deadpool-wolverine_866a70e7-fb48-4f35-a44b-41594691ac76_480x.progressive.png', ''),
(1004, 'Inside Out 2', 'Animation', '2025-12-12', '15:15', '35000', '2', 'inside_out_two_ver2_480x.progressive.png', 'https://youtube.com/embed/hDZ7y8RP5HE?si'),
(1005, 'Moana 2', 'Animation', '2025-12-12', '16:16', '35.000', '1', 'moana-2_c6chd7yn_480x.progressive.png', ''),
(1006, 'Bad Boys', 'Action', '2025-12-12', '14:14', '35.000', '2', 'badboys.mpw.122590_480x.progressive.png', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kursi`
--

CREATE TABLE `kursi` (
  `id` int(5) NOT NULL,
  `booking_id` varchar(50) NOT NULL,
  `seat_number` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemesanan_kursi`
--

CREATE TABLE `pemesanan_kursi` (
  `id` int(11) NOT NULL,
  `booking_id` varchar(255) NOT NULL,
  `kursi` varchar(5) NOT NULL,
  `harga` decimal(10,0) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pemesanan_kursi`
--

INSERT INTO `pemesanan_kursi` (`id`, `booking_id`, `kursi`, `harga`, `status`) VALUES
(218, 'TCS20241227123949793', 'C8', 35000, 0),
(219, 'TCS20241227124102349', 'C8', 35, 1),
(220, 'TCS20241227134707518', 'F7', 35000, 1),
(221, 'TCS20241227135714936', 'C2', 35000, 1),
(222, 'TCS20241227135714936', 'D3', 35000, 1),
(223, 'TCS20241227135714936', 'C4', 35000, 1),
(224, 'TCS20241227150500326', 'E10', 35000, 0),
(225, 'TCS20241227151147405', 'C10', 35000, 0),
(226, 'TCS20241227151147405', 'D10', 35000, 0),
(227, 'TCS20241227151230661', 'F8', 35, 1),
(228, 'TCS20241227160356194', 'F3', 35000, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tiket`
--

CREATE TABLE `tiket` (
  `username` varchar(50) NOT NULL,
  `booking_id` varchar(255) NOT NULL,
  `film_id` varchar(255) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `tanggal` varchar(50) NOT NULL,
  `waktu` varchar(255) NOT NULL,
  `theater` varchar(50) NOT NULL,
  `total_seats` varchar(50) NOT NULL,
  `total_price` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tiket`
--

INSERT INTO `tiket` (`username`, `booking_id`, `film_id`, `judul`, `tanggal`, `waktu`, `theater`, `total_seats`, `total_price`, `created_at`) VALUES
('masadita', 'TCS20241227123949793', '1003', 'Deadpool & Wolverine', '2025-12-12', '12:12', '1', '1', '35000', '2024-12-27 05:39:49'),
('masadita', 'TCS20241227124102349', '1002', 'Toy Story', '2025-12-12', '15:15', '4', '1', '35', '2024-12-27 05:41:02'),
('masadita', 'TCS20241227134707518', '1004', 'Inside Out 2', '2025-12-12', '15:15', '2', '1', '35000', '2024-12-27 06:47:07'),
('masadita', 'TCS20241227135714936', '1001', 'Venom 2', '2025-12-12', '12:21', '2', '3', '105000', '2024-12-27 06:57:14'),
('masadita', 'TCS20241227150500326', '1003', 'Deadpool & Wolverine', '2025-12-12', '12:12', '1', '1', '35000', '2024-12-27 08:05:00'),
('masadita1', 'TCS20241227151147405', '1001', 'Venom 2', '2025-12-12', '12:21', '2', '2', '70000', '2024-12-27 08:11:47'),
('masadita1', 'TCS20241227151230661', '1005', 'Moana 2', '2025-12-12', '16:16', '1', '1', '35', '2024-12-27 08:12:30'),
('masadita1', 'TCS20241227160356194', '1001', 'Venom 2', '2025-12-12', '12:21', '2', '1', '35000', '2024-12-27 09:03:56');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(3) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `no_hp` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `email`, `username`, `password`, `nama_lengkap`, `no_hp`) VALUES
(7, 'masadita20@gmail.com', 'masadita', '$2y$10$nrwh5/9K.Rj0iim9KLzpRuaq1YcEkEbT7h.HwypMs2g.12sZEQpYy', 'Zidan Masadita', '08124124124'),
(9, 'masadita201@gmail.com', 'masaditaa', '$2y$10$HencOtrF1JQqCJC7zyaeJOnK1VmwOQAEjvopPzuqFFzkZZjtRhCTy', 'Zidan Masadita', '08124123123'),
(10, 'masadita20a@gmail.com', 'masadita1', '$2y$10$VoE3hAwAQVvX4Q6oM2o4BuMOUMXsATZJzmHf8vRYsZPunYEGc6rT6', 'Zidan Masadita', '0812412312412');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`username_admin`);

--
-- Indeks untuk tabel `carousel_image`
--
ALTER TABLE `carousel_image`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `coming_soon`
--
ALTER TABLE `coming_soon`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `film`
--
ALTER TABLE `film`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kursi`
--
ALTER TABLE `kursi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pemesanan_kursi`
--
ALTER TABLE `pemesanan_kursi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `carousel_image`
--
ALTER TABLE `carousel_image`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `coming_soon`
--
ALTER TABLE `coming_soon`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92754;

--
-- AUTO_INCREMENT untuk tabel `film`
--
ALTER TABLE `film`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1361437;

--
-- AUTO_INCREMENT untuk tabel `kursi`
--
ALTER TABLE `kursi`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT untuk tabel `pemesanan_kursi`
--
ALTER TABLE `pemesanan_kursi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=229;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
